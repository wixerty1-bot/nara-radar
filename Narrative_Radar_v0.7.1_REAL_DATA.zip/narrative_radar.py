
import tkinter as tk
from tkinter import ttk, messagebox
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import html
import re
import threading
import webbrowser
import json
import os
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

APP_TITLE = "Narrative Radar"

# Public Reddit RSS feeds. No Reddit API key is required for this MVP.
FEEDS = {
    "Animals": [
        "https://www.reddit.com/r/AnimalsBeingDerps/.rss?limit=50",
        "https://www.reddit.com/r/aww/.rss?limit=50",
        "https://www.reddit.com/r/WhatsWrongWithYourDog/.rss?limit=50",
        "https://www.reddit.com/r/OneOrangeBraincell/.rss?limit=50",
        "https://www.reddit.com/r/CatsStandingUp/.rss?limit=50",
        "https://www.reddit.com/r/cats/.rss?limit=50",
        "https://www.reddit.com/r/dogs/.rss?limit=50",
    ],
    "Viral": [
        "https://www.reddit.com/r/interestingasfuck/.rss?limit=50",
        "https://www.reddit.com/r/Damnthatsinteresting/.rss?limit=50",
        "https://www.reddit.com/r/Unexpected/.rss?limit=50",
        "https://www.reddit.com/r/videos/.rss?limit=50",
    ],
    "Memes": [
        "https://www.reddit.com/r/memes/.rss?limit=50",
        "https://www.reddit.com/r/funny/.rss?limit=50",
        "https://www.reddit.com/r/okbuddyretard/.rss?limit=50",
    ]
}

ANIMAL_TERMS = {
    "raccoon": ("🦝 Raccoon", 97), "otter": ("🦦 Otter", 95), "monkey": ("🐒 Monkey", 95),
    "fox": ("🦊 Fox", 92), "bear": ("🐻 Bear", 90), "cat": ("🐈 Cat", 89),
    "kitten": ("🐈 Cat", 90), "dog": ("🐕 Dog", 89), "puppy": ("🐕 Dog", 90),
    "goat": ("🐐 Goat", 84), "horse": ("🐎 Horse", 82), "cow": ("🐄 Cow", 82),
    "duck": ("🦆 Duck", 86), "bird": ("🐦 Bird", 83), "parrot": ("🦜 Parrot", 86),
    "penguin": ("🐧 Penguin", 91), "hamster": ("🐹 Hamster", 87), "rabbit": ("🐇 Rabbit", 85),
    "bunny": ("🐇 Rabbit", 85), "squirrel": ("🐿️ Squirrel", 85), "snake": ("🐍 Snake", 81),
    "deer": ("🦌 Deer", 84), "lion": ("🦁 Lion", 88), "tiger": ("🐅 Tiger", 88),
    "frog": ("🐸 Frog", 84), "pig": ("🐷 Pig", 82), "chicken": ("🐔 Chicken", 82),
}

T = {
"ru": {
    "subtitle":"Мульти-соцсетевой радар • без AI", "scan":"↻  Сканировать", "import":"＋  Добавить URL",
    "sources":"ИСТОЧНИКИ", "all":"Все источники", "animals":"Животные", "viral":"Вирусное", "memes":"Мемы",
    "platform":"ПЛАТФОРМЫ", "reddit":"Reddit", "x":"X", "tiktok":"TikTok", "instagram":"Instagram", "facebook":"Facebook",
    "filters":"ФИЛЬТРЫ", "period":"Период", "minscore":"Минимальный score", "sort":"Сортировка",
    "apply":"Применить", "reset":"Сбросить", "pipeline":"PIPELINE",
    "collector":"Сбор данных", "media":"Media extraction", "metrics":"Метрики", "ai":"AI-анализ", "cluster":"Narrative-кластеры",
    "coin":"Coin history", "alerts":"Уведомления", "live":"LIVE DATA", "fallback":"DEMO FALLBACK",
    "opportunity":"ВОЗМОЖНОСТЬ", "open":"Открыть", "media_open":"Открыть media", "narrative":"Narrative",
    "coin_history":"COIN HISTORY", "not_checked":"Не проверено", "no_coins":"Значимых койнов не найдено",
    "results":"результатов", "loading":"Собираем публичные данные…", "no":"Нет реальных результатов по текущим фильтрам. Нажми «Сканировать».",
    "no_live":"LIVE DATA • пока ничего не получено",
    "views":"Просмотры", "likes":"Лайки / Upvotes", "comments":"Комментарии", "growth":"Рост",
    "direct":"Оригинал", "media_type":"Media", "demo":"demo",
    "url_title":"Добавить ссылку", "url_hint":"Вставь ссылку на пост/ролик (Reddit, X, TikTok, Instagram, Facebook):",
    "url_add":"Добавить", "cancel":"Отмена", "saved":"Ссылка добавлена в радар.",
    "platform_soon":"подготовлено"
},
"en": {
    "subtitle":"Multi-social radar • AI OFF", "scan":"↻  Scan", "import":"＋  Add URL",
    "sources":"SOURCES", "all":"All sources", "animals":"Animals", "viral":"Viral", "memes":"Memes",
    "platform":"PLATFORMS", "reddit":"Reddit", "x":"X", "tiktok":"TikTok", "instagram":"Instagram", "facebook":"Facebook",
    "filters":"FILTERS", "period":"Time window", "minscore":"Minimum score", "sort":"Sort",
    "apply":"Apply", "reset":"Reset", "pipeline":"PIPELINE",
    "collector":"Data collectors", "media":"Media extraction", "metrics":"Metrics", "ai":"AI analysis", "cluster":"Narrative clusters",
    "coin":"Coin history", "alerts":"Alerts", "live":"LIVE DATA", "fallback":"DEMO FALLBACK",
    "opportunity":"OPPORTUNITY", "open":"Open", "media_open":"Open media", "narrative":"Narrative",
    "coin_history":"COIN HISTORY", "not_checked":"Not checked", "no_coins":"No significant coins found",
    "results":"results", "loading":"Collecting public data…", "no":"No live results match these filters. Press Scan to retry.",
    "no_live":"LIVE DATA • no live items received",
    "views":"Views", "likes":"Likes / Upvotes", "comments":"Comments", "growth":"Growth",
    "direct":"Original", "media_type":"Media", "demo":"demo",
    "url_title":"Add URL", "url_hint":"Paste a post/video URL (Reddit, X, TikTok, Instagram, Facebook):",
    "url_add":"Add", "cancel":"Cancel", "saved":"URL added to radar.",
    "platform_soon":"prepared"
}}

# DEMO DISABLED IN v0.7.1. Real collector only.
DEMO = [
    {"animal":"🦝 Raccoon","title":"Raccoon rides a robot vacuum","narrative":"Raccoon doing human things",
     "platform":"Reddit","views":0,"likes":0,"comments":0,"age_h":7,"meme":96,"unique":94,"viral":87,
     "fresh":99,"growth":86,"score":89,"token":"⚪ Not checked","ath":"—","url":"https://www.reddit.com/","media_url":"",
     "media_type":"image","is_demo":True},
    {"animal":"🐒 Monkey","title":"Monkey steals a police hat","narrative":"Monkey steals human objects",
     "platform":"Reddit","views":0,"likes":0,"comments":0,"age_h":11,"meme":91,"unique":93,"viral":95,
     "fresh":93,"growth":91,"score":90,"token":"⚪ Not checked","ath":"—","url":"https://www.reddit.com/","media_url":"",
     "media_type":"video","is_demo":True},
]

SORTS_RU = ["Возможность","Просмотры","Лайки / Upvotes","Комментарии","Мемность","Уникальность","Виральность","Рост","Свежесть"]
SORTS_EN = ["Opportunity","Views","Likes / Upvotes","Comments","Meme score","Uniqueness","Virality","Growth","Freshness"]

def safe_url_open(url):
    if url:
        webbrowser.open(url)

def fmt_num(n):
    if n is None or n == 0:
        return "—"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)

class Radar(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1420x900")
        self.minsize(1120, 740)

        self.language = "ru"
        self.mode = "Animals"
        self.platform = "All"
        self.results = []
        self.scanning = False
        self.min_score = tk.DoubleVar(value=0)
        self.sort_internal = "score"

        self.bg="#15181d"; self.sidebar_bg="#1b1f25"; self.surface="#20252c"; self.card_bg="#242a31"
        self.input_bg="#2a3038"; self.border="#313842"; self.text="#d9dee5"; self.muted="#8f98a6"; self.soft="#b9c0c9"
        self.accent="#769f8b"; self.accent_hover="#90b19e"

        self.configure(bg=self.bg)
        self.setup_style()
        self.build()
        self.localize()
        self.show_demo()
        self.scan_async()

    def setup_style(self):
        s=ttk.Style(self)
        try: s.theme_use("clam")
        except: pass
        s.configure(".",background=self.bg,foreground=self.text,font=("Segoe UI",10))
        s.configure("TFrame",background=self.bg)
        s.configure("Sidebar.TFrame",background=self.sidebar_bg)
        s.configure("Surface.TFrame",background=self.surface)
        s.configure("Card.TFrame",background=self.card_bg)
        s.configure("TLabel",background=self.bg,foreground=self.text)
        s.configure("Muted.TLabel",background=self.bg,foreground=self.muted,font=("Segoe UI",9))
        s.configure("Title.TLabel",background=self.bg,foreground=self.text,font=("Segoe UI",18,"bold"))
        s.configure("SideHead.TLabel",background=self.sidebar_bg,foreground=self.muted,font=("Segoe UI",8,"bold"))
        s.configure("SideText.TLabel",background=self.sidebar_bg,foreground=self.text,font=("Segoe UI",9))
        s.configure("CardTitle.TLabel",background=self.card_bg,foreground=self.text,font=("Segoe UI",12,"bold"))
        s.configure("CardText.TLabel",background=self.card_bg,foreground=self.soft)
        s.configure("CardMuted.TLabel",background=self.card_bg,foreground=self.muted,font=("Segoe UI",9))
        s.configure("Big.TLabel",background=self.card_bg,foreground=self.text,font=("Segoe UI",25,"bold"))
        s.configure("TButton",background=self.input_bg,foreground=self.text,borderwidth=0,padding=(10,7))
        s.map("TButton",background=[("active",self.border)])
        s.configure("Accent.TButton",background=self.accent,foreground="#132019",padding=(12,8))
        s.map("Accent.TButton",background=[("active",self.accent_hover)])
        s.configure("TCombobox",fieldbackground=self.input_bg,background=self.input_bg,foreground=self.text,arrowcolor=self.muted,borderwidth=0)
        s.configure("TScale",background=self.sidebar_bg,troughcolor=self.border)

    def build(self):
        top=ttk.Frame(self); top.pack(fill="x",padx=26,pady=(20,12))
        left=ttk.Frame(top); left.pack(side="left")
        ttk.Label(left,text="🧬  NARRATIVE RADAR",style="Title.TLabel").pack(anchor="w")
        self.sub=ttk.Label(left,style="Muted.TLabel"); self.sub.pack(anchor="w",pady=(3,0))

        right=ttk.Frame(top); right.pack(side="right")
        self.status=ttk.Label(right,style="Muted.TLabel"); self.status.pack(side="left",padx=(0,12))
        self.lang_btn=ttk.Button(right,width=6,command=self.toggle_language); self.lang_btn.pack(side="left",padx=(0,8))
        self.import_btn=ttk.Button(right,command=self.add_url_dialog); self.import_btn.pack(side="left",padx=(0,8))
        self.scan=ttk.Button(right,style="Accent.TButton",command=self.scan_async); self.scan.pack(side="left")

        body=ttk.Frame(self); body.pack(fill="both",expand=True,padx=26,pady=6)
        self.side=ttk.Frame(body,style="Sidebar.TFrame",width=270); self.side.pack(side="left",fill="y",padx=(0,16)); self.side.pack_propagate(False)

        self._section("sources")
        self.source_buttons={}
        for k in ["All","Animals","Viral","Memes"]: self._button(k,"source")

        self._section("platform")
        self.platform_buttons={}
        for k in ["All","Reddit","X","TikTok","Instagram","Facebook"]: self._button(k,"platform")

        self._section("filters")
        self.date_label=ttk.Label(self.side,style="SideHead.TLabel"); self.date_label.pack(anchor="w",padx=18,pady=(0,5))
        self.date=ttk.Combobox(self.side,state="readonly",width=22); self.date.pack(fill="x",padx=18,pady=(0,8))
        self.min_label=ttk.Label(self.side,style="SideHead.TLabel"); self.min_label.pack(anchor="w",padx=18,pady=(5,5))
        row=ttk.Frame(self.side,style="Sidebar.TFrame"); row.pack(fill="x",padx=18)
        self.min_value=ttk.Label(row,text="0",background=self.sidebar_bg,foreground=self.text); self.min_value.pack(side="right")
        ttk.Scale(row,from_=0,to=100,variable=self.min_score,command=lambda v:self.min_value.config(text=str(int(float(v))))).pack(side="left",fill="x",expand=True)
        self.sort_label=ttk.Label(self.side,style="SideHead.TLabel"); self.sort_label.pack(anchor="w",padx=18,pady=(12,5))
        self.sort=ttk.Combobox(self.side,state="readonly",width=22); self.sort.pack(fill="x",padx=18,pady=(0,8))
        bb=ttk.Frame(self.side,style="Sidebar.TFrame"); bb.pack(fill="x",padx=18)
        self.apply=ttk.Button(bb,command=self.apply_filters); self.apply.pack(side="left",fill="x",expand=True)
        self.reset=ttk.Button(bb,command=self.reset_filters); self.reset.pack(side="left",padx=(6,0))

        ttk.Separator(self.side).pack(fill="x",padx=18,pady=18)
        self.pipe=ttk.Label(self.side,style="SideHead.TLabel"); self.pipe.pack(anchor="w",padx=18)
        self.pipe_labels=[]
        for _ in range(6):
            l=ttk.Label(self.side,style="SideText.TLabel"); l.pack(anchor="w",padx=18,pady=3); self.pipe_labels.append(l)

        main=ttk.Frame(body); main.pack(side="left",fill="both",expand=True)
        self.summary=ttk.Label(main,style="Muted.TLabel"); self.summary.pack(anchor="w",pady=(0,8))
        wrap=ttk.Frame(main,style="Surface.TFrame"); wrap.pack(fill="both",expand=True)
        self.canvas=tk.Canvas(wrap,bg=self.surface,highlightthickness=0)
        sb=ttk.Scrollbar(wrap,orient="vertical",command=self.canvas.yview)
        self.list_frame=ttk.Frame(self.canvas,style="Surface.TFrame")
        self.list_frame.bind("<Configure>",lambda e:self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.win=self.canvas.create_window((0,0),window=self.list_frame,anchor="nw")
        self.canvas.bind("<Configure>",lambda e:self.canvas.itemconfigure(self.win,width=e.width))
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y")
        self.canvas.bind_all("<MouseWheel>",lambda e:self.canvas.yview_scroll(int(-e.delta/120),"units"))

    def _section(self,name):
        l=ttk.Label(self.side,style="SideHead.TLabel"); l.pack(anchor="w",padx=18,pady=(16,7)); setattr(self,"section_"+name,l)

    def _button(self,key,group):
        f=tk.Frame(self.side,bg=self.sidebar_bg); f.pack(fill="x",padx=12,pady=2)
        b=tk.Button(f,text=key,bg=self.card_bg,fg=self.text,activebackground=self.border,activeforeground=self.text,
                    relief="flat",bd=0,anchor="w",padx=10,pady=7,font=("Segoe UI",9),
                    command=lambda k=key,g=group:self.choose(k,g))
        b.pack(fill="x",expand=True)
        if group=="source": self.source_buttons[key]=b
        else: self.platform_buttons[key]=b

    def choose(self,key,group):
        if group=="source":
            self.mode="Animals" if key=="All" else key
            for k,b in self.source_buttons.items():
                sel=(k==key); b.configure(bg=self.accent if sel else self.card_bg,fg="#132019" if sel else self.text)
        else:
            self.platform=key
            for k,b in self.platform_buttons.items():
                sel=(k==key); b.configure(bg=self.accent if sel else self.card_bg,fg="#132019" if sel else self.text)
        self.refresh_view()

    def toggle_language(self):
        self.language="en" if self.language=="ru" else "ru"
        self.localize()
        self.refresh_view()

    def localize(self):
        t=T[self.language]
        self.sub.config(text=t["subtitle"]); self.scan.config(text=t["scan"]); self.import_btn.config(text=t["import"])
        self.lang_btn.config(text="EN" if self.language=="ru" else "RU")
        self.section_sources.config(text=t["sources"]); self.section_platform.config(text=t["platform"]); self.section_filters.config(text=t["filters"])
        self.date_label.config(text=t["period"]); self.min_label.config(text=t["minscore"]); self.sort_label.config(text=t["sort"])
        self.apply.config(text=t["apply"]); self.reset.config(text=t["reset"]); self.pipe.config(text=t["pipeline"])
        self.pipe_labels[0].config(text="✓ "+t["collector"]+" • Reddit")
        self.pipe_labels[1].config(text="✓ "+t["media"]+" • ready")
        self.pipe_labels[2].config(text="✓ "+t["metrics"]+" • source-dependent")
        self.pipe_labels[3].config(text="○ "+t["ai"]+" • OFF")
        self.pipe_labels[4].config(text="○ "+t["cluster"]+" • prepared")
        self.pipe_labels[5].config(text="○ "+t["coin"]+" • prepared")
        src={"All":t["all"],"Animals":t["animals"],"Viral":t["viral"],"Memes":t["memes"]}
        for k,b in self.source_buttons.items(): b.config(text=src[k])
        for k,b in self.platform_buttons.items():
            labels={"All":t["all"],"Reddit":"Reddit","X":"X","TikTok":"TikTok","Instagram":"Instagram","Facebook":"Facebook"}
            b.config(text=labels[k])
        self.date["values"]=["1 hour","6 hours","24 hours","2 days","7 days"] if self.language=="en" else ["1 час","6 часов","24 часа","2 дня","7 дней"]
        if not self.date.get(): self.date.set(self.date["values"][-1])
        self.sort["values"]=SORTS_EN if self.language=="en" else SORTS_RU
        self.sort.set(self.sort["values"][0])

    def reset_filters(self):
        self.min_score.set(0); self.min_value.config(text="0")
        self.mode="Animals"; self.platform="All"
        for k,b in self.source_buttons.items(): b.configure(bg=self.accent if k=="Animals" else self.card_bg,fg="#132019" if k=="Animals" else self.text)
        for k,b in self.platform_buttons.items(): b.configure(bg=self.accent if k=="All" else self.card_bg,fg="#132019" if k=="All" else self.text)
        self.refresh_view()

    def apply_filters(self):
        idx=self.sort.current()
        if idx < 0: idx=0
        self.sort_internal=["score","views","likes","comments","meme","unique","viral","growth","fresh"][idx]
        self.refresh_view()

    def show_demo(self):
        self.results = []
        self.status.config(text=T[self.language]["loading"])
        self.refresh_view()

    def scan_async(self):
        if self.scanning: return
        self.scanning=True
        self.scan.config(state="disabled")
        self.status.config(text=T[self.language]["loading"])
        threading.Thread(target=self.worker,daemon=True).start()

    def worker(self):
        items=[]; errors=0
        if self.platform in ("All","Reddit"):
            for url in FEEDS.get(self.mode,FEEDS["Animals"]):
                try: items.extend(self.fetch_reddit_rss(url))
                except Exception: errors+=1
        seen=set(); clean=[]
        for x in items:
            if x["url"] in seen: continue
            seen.add(x["url"]); clean.append(x)
        self.results = clean
        self.after(0,lambda:self.finish(bool(clean),errors))

    def fetch_reddit_rss(self,url):
        req=urllib.request.Request(url,headers={"User-Agent":"NarrativeRadar/0.7 personal research desktop app"})
        with urllib.request.urlopen(req,timeout=15) as r: raw=r.read()
        root=ET.fromstring(raw)
        out=[]
        for item in root.iter():
            if not item.tag.endswith("item"): continue
            title=self.child(item,"title")
            desc=self.child(item,"description")
            link=self.child(item,"link")
            pub=self.child(item,"pubDate")
            content=html.unescape(desc or "")
            post_html=content

            media_url=""
            media_type="none"

            # Pull image URLs from RSS description/content.
            imgs=re.findall(r'<img[^>]+src=["\\\']([^"\\\']+)["\\\']',post_html,re.I)
            if imgs:
                media_url=html.unescape(imgs[0])
                media_type="image"
            # enclosure / media:content / media:thumbnail
            for c in list(item):
                tag=c.tag.lower()
                u=c.attrib.get("url","")
                if u and ("enclosure" in tag or "content" in tag or "thumbnail" in tag):
                    if not media_url:
                        media_url=u
                        mt=(c.attrib.get("type") or "").lower()
                        media_type="video" if "video" in mt else ("image" if "image" in mt else "media")
            # direct reddit media href
            if not media_url:
                hrefs=re.findall(r'href=["\\\']([^"\\\']+)["\\\']',post_html,re.I)
                for h in hrefs:
                    if re.search(r'\.(jpg|jpeg|png|webp|gif|mp4|webm)(\?|$)',h,re.I):
                        media_url=html.unescape(h)
                        ext=h.lower().split("?")[0].split(".")[-1]
                        media_type="video" if ext in ("mp4","webm") else ("gif" if ext=="gif" else "image")
                        break

            text=f"{title} {content}"
            animal,base=self.animal(text)
            if not animal: continue
            age=self.hours(pub)
            fresh=max(55,min(100,int(100-min(age,168)/168*35)))
            meme=max(45,min(100,base+self.bonus(text,["wtf","chaos","unexpected","derp","insane","cursed","funny","weird","why","bro"],10)))
            unique=max(45,min(100,base+self.bonus(text,["first","never","somehow","apparently","strange","crazy","impossible","unexpected"],10)))
            # No invented view/like counts. Reddit RSS doesn't reliably expose them.
            viral=max(45,min(100,74+(7 if "comments" in text.lower() else 0)))
            growth=max(50,min(100,90-int(min(age,168)/168*20)))
            # Stricter Opportunity: 100 should be extremely rare without strong signals.
            score=int(.33*meme+.24*unique+.17*viral+.14*growth+.12*fresh)
            out.append({
                "animal":animal,"title":title or "Untitled","narrative":title or "Animal narrative",
                "platform":"Reddit","views":0,"likes":0,"comments":0,"age_h":age,
                "meme":meme,"unique":unique,"viral":viral,"fresh":fresh,"growth":growth,"score":score,
                "token":"⚪ Not checked","ath":"—","url":link or "https://www.reddit.com/",
                "media_url":media_url,"media_type":media_type,"is_demo":False,
                "subreddit":self.subreddit_from_url(link)
            })
        return out

    def child(self,p,name):
        for c in list(p):
            if c.tag.endswith(name): return "".join(c.itertext()).strip()
        return ""

    def animal(self,text):
        low=text.lower(); hits=[]
        for term,data in ANIMAL_TERMS.items():
            if re.search(r"\b"+re.escape(term)+r"\b",low): hits.append(data)
        return (max(hits,key=lambda x:x[1]) if hits else (None,0))

    def bonus(self,text,words,limit):
        return min(limit,sum(1 for w in words if w in text.lower())*2)

    def hours(self,pub):
        if not pub: return 24
        try:
            dt=parsedate_to_datetime(pub)
            return max(0,(datetime.now(timezone.utc)-dt.astimezone(timezone.utc)).total_seconds()/3600)
        except: return 24

    def subreddit_from_url(self,url):
        m=re.search(r"reddit\.com/r/([^/]+)",url or "")
        return "r/"+m.group(1) if m else "Reddit"

    def finish(self,live,errors):
        self.scanning=False
        self.scan.config(state="normal")
        if live:
            self.status.config(text=T[self.language]["live"])
        else:
            msg = T[self.language]["no_live"]
            if errors:
                msg += f" • {errors} feed(s) failed"
            self.status.config(text=msg)
        self.refresh_view()

    def refresh_view(self):
        for w in self.list_frame.winfo_children(): w.destroy()
        t=T[self.language]
        minimum=int(self.min_score.get())
        data=[x for x in self.results if (self.platform=="All" or x["platform"]==self.platform) and x["score"]>=minimum]
        data.sort(key=lambda x:x.get(self.sort_internal,0),reverse=True)
        demo=sum(1 for x in data if x.get("is_demo"))
        self.summary.config(text=f'{len(data)} {t["results"]} • {datetime.now().strftime("%H:%M:%S")}' + (f' • {t["demo"]}' if demo else ''))
        if not data:
            ttk.Label(self.list_frame,text=t["no"],background=self.surface,foreground=self.muted,font=("Segoe UI",11)).pack(pady=60)
            return
        for x in data: self.render_card(x)

    def render_card(self,x):
        t=T[self.language]
        c=ttk.Frame(self.list_frame,style="Card.TFrame",padding=16); c.pack(fill="x",padx=12,pady=6)
        left=ttk.Frame(c,style="Card.TFrame"); left.pack(side="left",fill="both",expand=True)
        row=ttk.Frame(left,style="Card.TFrame"); row.pack(fill="x")
        ttk.Label(row,text=f'{x["animal"]}  {x["title"]}',style="CardTitle.TLabel").pack(side="left")
        ttk.Label(row,text="DEMO" if x.get("is_demo") else x["platform"],background=self.input_bg,foreground=self.muted,font=("Segoe UI",8,"bold"),padding=(7,3)).pack(side="right")
        ttk.Label(left,text=f'🧬 {t["narrative"]}: {x["narrative"]}',style="CardText.TLabel").pack(anchor="w",pady=(6,3))
        likes = fmt_num(x.get("likes",0))
        comments = fmt_num(x.get("comments",0))
        views = fmt_num(x.get("views",0))
        ttk.Label(left,text=f'👁 {t["views"]}: {views}   •   ❤️/↑ {likes}   •   💬 {comments}   •   ⏱ {self.age_label(x["age_h"])}',
                  style="CardMuted.TLabel").pack(anchor="w")
        if x.get("subreddit"):
            ttk.Label(left,text=f'📍 {x["subreddit"]}   •   {t["media_type"]}: {x.get("media_type","none")}',
                      style="CardMuted.TLabel").pack(anchor="w",pady=(2,0))

        metrics=ttk.Frame(left,style="Card.TFrame"); metrics.pack(fill="x",pady=(10,0))
        for lab,val in [("MEME",x["meme"]),("UNIQUE",x["unique"]),("VIRAL",x["viral"]),("GROWTH",x["growth"]),("FRESH",x["fresh"])]:
            box=ttk.Frame(metrics,style="Card.TFrame"); box.pack(side="left",padx=(0,18))
            ttk.Label(box,text=lab,background=self.card_bg,foreground="#717b87",font=("Segoe UI",8,"bold")).pack(anchor="w")
            ttk.Label(box,text=f"{val}/100",background=self.card_bg,foreground=self.text,font=("Segoe UI",10,"bold")).pack(anchor="w")

        coin_line=f'{t["coin_history"]}: {x.get("token",t["not_checked"])}  •  ATH: {x.get("ath","—")}'
        ttk.Label(left,text="🪙 "+coin_line,style="CardMuted.TLabel").pack(anchor="w",pady=(7,0))

        right=ttk.Frame(c,style="Card.TFrame",width=155); right.pack(side="right",fill="y",padx=(14,0)); right.pack_propagate(False)
        ttk.Label(right,text=t["opportunity"],background=self.card_bg,foreground="#717b87",font=("Segoe UI",8,"bold")).pack(anchor="e")
        ttk.Label(right,text=str(x["score"]),style="Big.TLabel").pack(anchor="e")
        ttk.Button(right,text=t["open"],command=lambda u=x["url"]:safe_url_open(u)).pack(anchor="e",pady=(6,0))
        if x.get("media_url"):
            ttk.Button(right,text=t["media_open"],command=lambda u=x["media_url"]:safe_url_open(u)).pack(anchor="e",pady=(5,0))

        c.bind("<Button-1>",lambda e,x=x:self.details(x))
        for child in c.winfo_children():
            child.bind("<Button-1>",lambda e,x=x:self.details(x))
            for grand in child.winfo_children():
                grand.bind("<Button-1>",lambda e,x=x:self.details(x))

    def age_label(self,h):
        return "<1h" if h<1 else (f"{int(h)}h" if h<24 else f"{int(h/24)}d")

    def details(self,x):
        t=T[self.language]
        win=tk.Toplevel(self); win.title("Narrative Radar • Details"); win.geometry("760x700"); win.configure(bg=self.bg)
        ttk.Label(win,text=f'{x["animal"]}  {x["title"]}',style="Title.TLabel").pack(anchor="w",padx=24,pady=(22,4))
        ttk.Label(win,text=f'{t["narrative"]}: {x["narrative"]}',style="Muted.TLabel").pack(anchor="w",padx=24)
        text=tk.Text(win,bg=self.card_bg,fg=self.text,insertbackground=self.text,relief="flat",wrap="word",font=("Segoe UI",10),padx=14,pady=14)
        text.pack(fill="both",expand=True,padx=24,pady=18)
        lines=[
            f'Platform: {x["platform"]}',
            f'Age: {self.age_label(x["age_h"])}',
            f'{t["views"]}: {fmt_num(x.get("views",0))}',
            f'{t["likes"]}: {fmt_num(x.get("likes",0))}',
            f'{t["comments"]}: {fmt_num(x.get("comments",0))}',
            f'Meme: {x["meme"]}/100',
            f'Uniqueness: {x["unique"]}/100',
            f'Virality: {x["viral"]}/100',
            f'Growth: {x["growth"]}/100',
            f'Freshness: {x["fresh"]}/100',
            f'{t["opportunity"]}: {x["score"]}/100',
            '',
            f'{t["coin_history"]}: {x.get("token",t["not_checked"])}',
            f'ATH: {x.get("ath","—")}',
            '',
            f'Media type: {x.get("media_type","none")}',
            f'Post URL: {x.get("url","")}',
            f'Media URL: {x.get("media_url","") or "—"}',
            '',
            'AI: OFF (this build intentionally has no AI calls).'
        ]
        text.insert("1.0","\n".join(lines)); text.config(state="disabled")
        btn=ttk.Frame(win); btn.pack(fill="x",padx=24,pady=(0,20))
        ttk.Button(btn,text=t["open"],command=lambda u=x["url"]:safe_url_open(u)).pack(side="left")
        if x.get("media_url"): ttk.Button(btn,text=t["media_open"],command=lambda u=x["media_url"]:safe_url_open(u)).pack(side="left",padx=6)

    def add_url_dialog(self):
        t=T[self.language]
        win=tk.Toplevel(self); win.title(t["url_title"]); win.geometry("650x220"); win.configure(bg=self.bg)
        ttk.Label(win,text=t["url_hint"],wraplength=580).pack(anchor="w",padx=24,pady=(25,10))
        entry=tk.Entry(win,bg=self.input_bg,fg=self.text,insertbackground=self.text,relief="flat",font=("Segoe UI",10))
        entry.pack(fill="x",padx=24,pady=(0,16),ipady=8)
        row=ttk.Frame(win); row.pack(fill="x",padx=24)
        def add():
            u=entry.get().strip()
            if not re.match(r"https?://",u):
                messagebox.showerror("URL","Введите корректную ссылку.")
                return
            item=self.inspect_url(u)
            self.results.insert(0,item)
            self.refresh_view()
            win.destroy()
            messagebox.showinfo(APP_TITLE,t["saved"])
        ttk.Button(row,text=t["cancel"],command=win.destroy).pack(side="right")
        ttk.Button(row,text=t["url_add"],style="Accent.TButton",command=add).pack(side="right",padx=7)

    def inspect_url(self,u):
        low=u.lower()
        platform="Unknown"
        if "reddit.com" in low: platform="Reddit"
        elif "tiktok.com" in low: platform="TikTok"
        elif "instagram.com" in low: platform="Instagram"
        elif "facebook.com" in low or "fb.watch" in low: platform="Facebook"
        elif "x.com" in low or "twitter.com" in low: platform="X"
        media_type="video" if any(x in low for x in ["/video","/reel","/reels/","tiktok.com"]) else "media"
        return {"animal":"🔗 Imported","title":"Imported social URL","narrative":"Needs AI/content analysis",
                "platform":platform,"views":0,"likes":0,"comments":0,"age_h":0,"meme":0,"unique":0,"viral":0,
                "fresh":100,"growth":0,"score":0,"token":"⚪ Not checked","ath":"—","url":u,"media_url":"",
                "media_type":media_type,"is_demo":False,"subreddit":""}

if __name__=="__main__":
    Radar().mainloop()
