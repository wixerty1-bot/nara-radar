NARRATIVE RADAR v0.7.1 — REAL DATA ONLY

Important change:
- Demo cards are DISABLED. The app no longer falls back to fake/demo results.
- If the collector cannot fetch live data, the list stays empty and the status explains that no live items were received.

Currently live:
- Reddit RSS across multiple public feeds.
- Reddit media extraction where the feed exposes image/video URLs.
- Real post URLs are preserved.

Prepared but NOT falsely marked as live:
- X
- TikTok
- Instagram
- Facebook

This means an empty screen is now an honest signal that the current live collector did not return matching data.

Run:
- double-click run_radar.bat
