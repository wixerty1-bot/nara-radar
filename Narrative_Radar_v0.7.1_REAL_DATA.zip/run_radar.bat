@echo off
cd /d "%~dp0"
python narrative_radar.py
if errorlevel 1 pause
